STOPWORDS = {
    "a", "an", "and", "are", "as", "at", "be", "by", "for", "from", "how", "i", "in",
    "is", "it", "of", "on", "or", "that", "the", "this", "to", "was", "what", "when",
    "where", "which", "who", "why", "with", "you", "your",
}



def _tokenize(text):
    return {
        token
        for token in (text or "").lower().replace("?", " ").replace(",", " ").replace(".", " ").split()
        if token not in STOPWORDS and len(token) > 2
    }



def search_vector_db(query, embed_model, collection, k=4):
    if not query.strip() or collection.count() == 0:
        return []

    query_embedding = embed_model.encode(query).tolist()
    # Pull a wider candidate set, then rerank/filter locally.
    candidate_count = min(max(k * 4, 12), collection.count())
    results = collection.query(query_embeddings=[query_embedding], n_results=candidate_count)

    documents = results.get("documents", [[]])
    metadatas = results.get("metadatas", [[]])
    distances = results.get("distances", [[]])

    query_terms = _tokenize(query)
    items = []
    for index, text in enumerate(documents[0] if documents else []):
        metadata = (metadatas[0][index] if metadatas and metadatas[0] else {}) or {}
        distance = distances[0][index] if distances and distances[0] else None
        content_terms = _tokenize(text)
        overlap = len(query_terms & content_terms)
        items.append(
            {
                "content": text,
                "metadata": metadata,
                "distance": distance,
                "overlap": overlap,
            }
        )

    # Keep candidates that actually mention query terms, or are exceptionally close semantically.
    filtered = [
        item for item in items
        if item["overlap"] > 0 or (item["distance"] is not None and item["distance"] < 0.75)
    ]
    if not filtered:
        filtered = items[:k]

    filtered.sort(
        key=lambda item: (
            -item["overlap"],
            item["distance"] if item["distance"] is not None else 999,
        )
    )

    return [
        {
            "content": item["content"],
            "metadata": item["metadata"],
            "distance": item["distance"],
        }
        for item in filtered[:k]
    ]
